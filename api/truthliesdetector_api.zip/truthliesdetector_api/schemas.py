from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class CommentSchema(BaseModel):
    comment_id: int
    user_id: int
    article_id: int
    content: str
    commented_at: datetime
    user_identity: str
    class Config:
        orm_mode = True

class FavoriteSchema(BaseModel):
    favorite_id: int
    user_id: int
    article_id: int
    favorited_at: datetime
    class Config:
        orm_mode = True

class AnalysisResultSchema(BaseModel):
    analysis_id: int
    article_id: int
    user_id: int
    explanation: str
    analyzed_at: datetime
    keywords: str
    category: str
    confidence_score: float
    risk_level: str
    report_id: Optional[int]
    class Config:
        orm_mode = True

class RelatedNewsSchema(BaseModel):
    related_id: int
    source_article_id: int
    related_article_id: int
    similarity_score: float
    related_title: str
    related_link: str
    class Config:
        orm_mode = True

class ReportSchema(BaseModel):
    report_id: int
    user_id: int
    article_id: int
    reason: str
    status: str
    reported_at: datetime
    class Config:
        orm_mode = True

class SearchLogSchema(BaseModel):
    search_id: int
    user_id: int
    query: str
    search_result: str
    searched_at: datetime
    class Config:
        orm_mode = True

class UserSchema(BaseModel):
    user_id: int
    account: str
    username: str
    email: str
    class Config:
        orm_mode = True

class ArticleSchema(BaseModel):
    article_id: int
    title: str
    content: str
    category: str
    source_link: str
    media_name: str
    created_time: datetime
    published_time: datetime
    reliability_score: float
    comments: Optional[List[CommentSchema]] = []
    favorites: Optional[List[FavoriteSchema]] = []
    analysis_results: Optional[List[AnalysisResultSchema]] = []
    reports: Optional[List[ReportSchema]] = []
    related_news_sources: Optional[List[RelatedNewsSchema]] = []
    related_news_targets: Optional[List[RelatedNewsSchema]] = []
    class Config:
        orm_mode = True
