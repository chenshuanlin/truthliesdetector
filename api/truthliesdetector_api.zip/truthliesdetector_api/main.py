from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from database import SessionLocal, engine, Base
import models, schemas

# 建立資料表
Base.metadata.create_all(bind=engine)

app = FastAPI(title="TruthliesDetector API")

# 依賴
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# 取得所有文章
@app.get("/articles", response_model=list[schemas.ArticleSchema])
def read_articles(db: Session = Depends(get_db)):
    articles = db.query(models.Article).all()
    for article in articles:
        article.comments = db.query(models.Comment).filter(models.Comment.article_id==article.article_id).all()
        article.favorites = db.query(models.Favorite).filter(models.Favorite.article_id==article.article_id).all()
        article.analysis_results = db.query(models.AnalysisResult).filter(models.AnalysisResult.article_id==article.article_id).all()
        article.reports = db.query(models.Report).filter(models.Report.article_id==article.article_id).all()
        article.related_news_sources = db.query(models.RelatedNews).filter(models.RelatedNews.source_article_id==article.article_id).all()
        article.related_news_targets = db.query(models.RelatedNews).filter(models.RelatedNews.related_article_id==article.article_id).all()
    return articles

# 取得單篇文章
@app.get("/articles/{article_id}", response_model=schemas.ArticleSchema)
def read_article(article_id: int, db: Session = Depends(get_db)):
    article = db.query(models.Article).filter(models.Article.article_id==article_id).first()
    if article:
        article.comments = db.query(models.Comment).filter(models.Comment.article_id==article.article_id).all()
        article.favorites = db.query(models.Favorite).filter(models.Favorite.article_id==article.article_id).all()
        article.analysis_results = db.query(models.AnalysisResult).filter(models.AnalysisResult.article_id==article.article_id).all()
        article.reports = db.query(models.Report).filter(models.Report.article_id==article.article_id).all()
        article.related_news_sources = db.query(models.RelatedNews).filter(models.RelatedNews.source_article_id==article.article_id).all()
        article.related_news_targets = db.query(models.RelatedNews).filter(models.RelatedNews.related_article_id==article.article_id).all()
    return article

# 取得所有使用者
@app.get("/users", response_model=list[schemas.UserSchema])
def read_users(db: Session = Depends(get_db)):
    return db.query(models.User).all()
